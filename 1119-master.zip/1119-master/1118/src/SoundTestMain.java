
public class SoundTestMain {

	public static void main(String[] args) {
		new SoundTestPanel();

	}

}
