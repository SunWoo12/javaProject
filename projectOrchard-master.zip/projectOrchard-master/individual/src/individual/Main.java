package individual;

public class Main
{
	public static void main(String[] args)
	{
		MainUI main = new MainUI();
	}

}
